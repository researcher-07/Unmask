'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const { spawn } = require('node:child_process');
const { WebSocket: ClientWebSocket } = require('ws');

let child;
let base;
let port;
const clients = new Set();

function freePort() {
  return new Promise((resolve, reject) => {
    const s = http.createServer();
    s.once('error', reject);
    s.listen(0, '127.0.0.1', () => {
      const p = s.address().port;
      s.close(err => err ? reject(err) : resolve(p));
    });
  });
}
function fetchText(url, options = {}) {
  return new Promise((resolve, reject) => {
    const req = http.request(url, options, res => {
      let body = '';
      res.setEncoding('utf8');
      res.on('data', chunk => body += chunk);
      res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body }));
    });
    req.on('error', reject);
    req.end();
  });
}
function waitFor(ws, predicate, timeout = 4000) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => { cleanup(); reject(new Error('Timed out waiting for WebSocket message')); }, timeout);
    function onMessage(raw) {
      let value;
      try { value = JSON.parse(raw.toString()); }
      catch { return; }
      if (!predicate(value)) return;
      cleanup(); resolve(value);
    }
    function cleanup() { clearTimeout(timer); ws.off('message', onMessage); }
    ws.on('message', onMessage);
  });
}
async function connect() {
  const ws = new ClientWebSocket(`ws://127.0.0.1:${port}/ws`, { origin: base });
  clients.add(ws);
  ws.once('close', () => clients.delete(ws));
  await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('WebSocket connection timed out')), 4000);
    ws.once('open', () => { clearTimeout(timer); resolve(); });
    ws.once('error', err => { clearTimeout(timer); reject(err); });
  });
  await waitFor(ws, m => m.type === 'ready');
  return ws;
}
function send(ws, object) { ws.send(JSON.stringify(object)); }

// These tests run after `npm install` and use Node's built-in WebSocket client.
test.before(async () => {
  port = await freePort();
  base = `http://127.0.0.1:${port}`;
  child = spawn(process.execPath, ['server.js'], {
    cwd: __dirname + '/..',
    env: { ...process.env, PORT: String(port) },
    stdio: ['ignore', 'pipe', 'pipe']
  });
  let logs = '';
  child.stdout.on('data', d => logs += d.toString());
  child.stderr.on('data', d => logs += d.toString());
  const start = Date.now();
  while (Date.now() - start < 7000) {
    if (child.exitCode !== null) throw new Error(`UNMASK server exited early: ${logs}`);
    try {
      const response = await fetchText(`${base}/`);
      if (response.status === 200) return;
    } catch { /* wait until listen */ }
    await new Promise(r => setTimeout(r, 100));
  }
  throw new Error(`UNMASK server did not start: ${logs}`);
});
test.after(async () => {
  for (const ws of clients) { try { ws.close(); } catch {} }
  if (child && child.exitCode === null) child.kill('SIGTERM');
});

test('serves the app with safe headers and does not expose source files', async () => {
  const health = await fetchText(`${base}/healthz`);
  assert.equal(health.status, 200);
  assert.equal(health.body, 'ok');
  const home = await fetchText(`${base}/`);
  assert.equal(home.status, 200);
  assert.match(home.body, /Less swiping/);
  assert.equal(home.headers['x-content-type-options'], 'nosniff');
  assert.equal(home.headers['x-frame-options'], 'DENY');
  for (const pathname of ['/server.js', '/package.json', '/README.md', '/.env', '/index.pre-refine.html']) {
    const result = await fetchText(`${base}${pathname}`);
    assert.equal(result.status, 404, `${pathname} should not be public`);
  }
  const posted = await fetchText(`${base}/`, { method: 'POST' });
  assert.equal(posted.status, 405);
});

test('creates a private room and pairs two clients; forwards only validated signaling', async () => {
  const host = await connect();
  const guest = await connect();
  send(host, { type: 'create-room', name: 'Host', vibe: 'Real', privacy: 'invite' });
  const created = await waitFor(host, m => m.type === 'room-created');
  assert.match(created.code, /^[A-HJ-NP-Z2-9]{5}$/);
  const readyHost = waitFor(host, m => m.type === 'peer-ready');
  const readyGuest = waitFor(guest, m => m.type === 'peer-ready');
  send(guest, { type: 'join-room', name: 'Guest', code: created.code });
  assert.equal((await readyHost).source, 'room');
  assert.equal((await readyGuest).source, 'room');
  const signal = waitFor(guest, m => m.type === 'signal');
  send(host, { type: 'signal', data: { kind: 'offer', description: { type: 'offer', sdp: 'v=0\r\n' } } });
  assert.equal((await signal).data.kind, 'offer');
  const badSignal = waitFor(host, m => m.type === 'error' && m.code === 'BAD_SIGNAL');
  send(guest, { type: 'signal', data: { kind: 'javascript', payload: '<script>' } });
  await badSignal;
  host.close(); guest.close();
});

test('passphrase-protected rooms reject incorrect phrases and accept correct ones', async () => {
  const host = await connect();
  const guest = await connect();
  send(host, { type: 'create-room', name: 'Host', vibe: 'Deep', privacy: 'password', password: 'correct horse' });
  const created = await waitFor(host, m => m.type === 'room-created');
  const wrong = waitFor(guest, m => m.type === 'error' && m.code === 'BAD_PASSWORD');
  send(guest, { type: 'join-room', name: 'Guest', code: created.code, password: 'wrong phrase' });
  await wrong;
  const readyHost = waitFor(host, m => m.type === 'peer-ready');
  const readyGuest = waitFor(guest, m => m.type === 'peer-ready');
  send(guest, { type: 'join-room', name: 'Guest', code: created.code, password: 'correct horse' });
  await readyHost; await readyGuest;
  host.close(); guest.close();
});
