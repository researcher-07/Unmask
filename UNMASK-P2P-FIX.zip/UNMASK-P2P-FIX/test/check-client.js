'use strict';
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const assert = require('node:assert/strict');
const root = path.join(__dirname, '..', 'public');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const blocks = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)];
assert.equal(blocks.length, 1, 'The app should have one inline application script');
new vm.Script(blocks[0][1], { filename: 'index.html:inline-script' });
for (const asset of ['manifest.json', 'service-worker.js', 'icon.svg', 'icon-192.png', 'icon-512.png', 'apple-touch-icon.png']) {
  assert.ok(fs.existsSync(path.join(root, asset)), `Missing app asset: ${asset}`);
}
for (const expected of ['Less swiping.', 'More revealing.', 'Start video call', 'Create<br>a room', 'Quick play', 'save-signaling-url']) {
  assert.ok(html.includes(expected), `Missing core product text/action: ${expected}`);
}

// Smoke-test actual initial rendering with a small DOM shim. This is not a
// substitute for cross-browser E2E tests, but it catches startup exceptions.
const elements = {
  app: { innerHTML: '' },
  'modal-root': { innerHTML: '' },
  toast: { textContent: '', classList: { add() {}, remove() {} } }
};
const document = {
  getElementById: id => elements[id] || null,
  querySelectorAll: () => [],
  addEventListener() {},
  createElement() { return { style: {}, classList: { add() {}, remove() {} }, remove() {}, select() {} }; }
};
const sandbox = {
  document,
  window: { scrollTo() {} },
  location: { protocol: 'file:', href: 'file:///unmask/index.html', hash: '', search: '' },
  navigator: {},
  localStorage: { getItem() { return null; }, setItem() {}, removeItem() {} },
  console,
  setTimeout,
  clearTimeout,
  URL,
  URLSearchParams,
  confirm: () => true
};
const context = vm.createContext(sandbox);
vm.runInContext(blocks[0][1], context, { filename: 'index.html:inline-runtime', timeout: 3000 });
assert.match(elements.app.innerHTML, /Less swiping/);
assert.match(elements.app.innerHTML, /More revealing/);
assert.match(elements.app.innerHTML, /Create<br>a room/);
assert.match(elements.app.innerHTML, /Quick play/);

// Exercise the local game loop: start Nova, answer, rate, and request next round.
vm.runInContext('startAI()', context);
assert.equal(vm.runInContext('state.view', context), 'game');
assert.match(elements.app.innerHTML, /Your answer/);
vm.runInContext('state.answerInput = "A small thing that makes me happy is a quiet walk."; submitAnswer()', context);
assert.match(elements.app.innerHTML, /How did that answer land\?/);
vm.runInContext('state.myRating = 5; submitRating()', context);
assert.equal(vm.runInContext('state.canAskNext', context), true);
assert.match(elements.app.innerHTML, /Next prompt with Nova/);
console.log('UNMASK client syntax, assets, initial render, and local game-loop smoke checks passed.');
