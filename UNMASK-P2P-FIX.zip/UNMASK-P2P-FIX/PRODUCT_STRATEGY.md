# UNMASK — product thesis and growth plan

## The wedge

**Turn the awkward first question into a repeatable ritual.** Do not compete by having the most questions. Compete on the quality of the conversation that happens after a prompt appears.

The strongest initial audience is not “everyone who likes games.” Start with one narrow behavior: two people who are curious about each other but need a low-pressure reason to start talking—friends at a hangout, a long-distance couple, a new match, or two people on a call.

## Product promise

“Start light. Go deeper only when you both want to.”

That promise should be visible in every mechanic:

- **Three entry paths:** private invite room, random live player, or an immediate local companion when the lobby is empty.
- **Vibe controls:** Real, Playful, Deep, Dark, and Chaos tune the question deck without making users fill out a long profile.
- **Prompt transparency:** show a clear preview before committing; give one-tap re-roll, skip, leave, and report controls.
- **Answer satisfaction:** stars and optional tags (genuine, thoughtful, funny, too vague) describe the answer's quality, not the player's identity or attractiveness.
- **Conversation continuity:** let both people save a non-sensitive moment title or a prompt to revisit, but never silently save private answers.
- **Consent as a feature:** passing never costs points, streaks, status, or access. Give both players control over pacing and intensity.

## Competitive reality check (October 2026)

The feature set alone is not defensible. Existing listings already advertise room codes, random/instant matchmaking, AI question ideas, reactions, and group play. For example, [Dare: Truth or Dare Online](https://play.google.com/store/apps/details?id=com.nadim.dare) lists private rooms, Instant Match, reactions, and AI question ideas; [Truth & Dare:Go Social Online](https://play.google.com/store/apps/details?hl=en_IN&id=com.truthordarego) lists random-player play and rooms with codes. Those are category expectations, not a moat.

The product bet should therefore be narrower and sharper: **a two-player connection ritual with transparent privacy, consent-aware prompt progression, local AI fallback, and answer-quality feedback**. Validate that users return with the same person and report a better conversation; do not rely on claims like “more questions” or “AI-powered” as the differentiator.

## Why someone might come back

The loop is:

1. **Fast start:** the first useful action happens in under 10 seconds.
2. **Warm-up:** the first prompt has low emotional risk.
3. **Personalization:** the next prompt is chosen from vibe, past skips, and user-selected depth—not from a hidden pressure algorithm.
4. **Mutual feedback:** after a response, the other person can rate its helpfulness or humor with lightweight tags.
5. **A reason to return:** share a “conversation pack,” invite the same person to a new vibe, or start a short “three-question check-in” the next day.

Avoid punitive streaks and addictive scarcity. Build ritual and trust instead of FOMO.

## Features to prioritize

### P0 — trustworthy core
- Reliable create/join room, random matchmaking, and graceful local companion fallback.
- One shared turn state machine with reconnect recovery and deterministic handling of simultaneous actions.
- Vibe-specific prompt packs, mixed Truth/Dare rounds, skip reasons optional, and clear turn status.
- Report, leave, block, mute, and age/safety policy suitable for the launch audience.
- Privacy notice, retention controls, room-code rate limits, abuse telemetry, and security review.

### P1 — retention that users choose
- “Three prompts, ten minutes” quick sessions.
- Private packs made by a user or couple; share by link.
- Consent-based session recap that stores only selected prompt IDs and a user-written memory title.
- Favorites, prompt quality feedback, and “less like this / more like this” controls.
- Friend re-invite and scheduled opt-in “question of the day” ritual.

### P2 — differentiation
- Adaptive prompt recommendations based on explicit feedback, not analysis of raw private answers.
- Party mode with a host-controlled player cap and safe turn rotation.
- Creator marketplace for themed packs (long-distance, new friends, family-safe, date night, team icebreakers) with a moderation and revenue-sharing policy.
- Optional voice/video only if demand is proven. Audio/video substantially increases abuse, moderation, bandwidth, and privacy complexity; it is not needed to validate the core loop.

## Monetization hypotheses

Validate willingness to pay before adding ads. A privacy-oriented conversation product should not put ads beside intimate answers.

- **Freemium:** free core rooms and a limited daily set of curated packs; paid tier for larger curated libraries, custom packs, couple rituals, and room themes.
- **Creator packs:** paid themed decks with transparent revenue sharing and content review.
- **Giftable sessions:** buy a themed pack for a partner or friend.
- **B2B later:** consent-first icebreaker packs for workshops or small teams, only after the two-player consumer loop works.

Do not charge for essential safety controls, skips, or privacy features.

## Metrics that matter

North-star candidate: **weekly mutually completed sessions** — sessions in which both players answer or pass at least three prompts and each reports a satisfactory experience. This is better than time spent or raw session count because both players must benefit.

Track the funnel:

- Landing → room created / quick play clicked.
- Entry → first prompt shown in <10 seconds.
- First prompt → first answer or pass.
- Round 1 → round 3 completion.
- Session end → invite share / repeat with the same partner.
- Post-session: “Did this help you connect?” and response satisfaction.
- Safety: report rate, block rate, exits shortly after a prompt, repeated reports, and prompt-specific skip spikes.

Segment results by entry path, vibe, region, new vs returning user, and AI vs human opponent. Audit against selection bias: players who choose deep prompts are not directly comparable to players who choose playful prompts.

## Early experiments

1. **Prompt-first vs game-first landing:** does previewing a sample question increase first-prompt starts?
2. **AI fallback timing:** test 6, 10, and 14 seconds. Optimize for a smooth experience without tricking users into thinking Nova is human.
3. **Suggested vs random prompt:** measure completion and satisfaction, not raw tap count.
4. **End-of-session ritual:** a user-chosen “save this prompt” vs “invite again.”
5. **Vibe onboarding:** select a vibe before entry vs let users change it after the first prompt.

Pre-register the success metric and safety guardrails for each experiment. A retention lift is not a win if report rates or regret scores rise.

## Architecture and privacy position

- Use WebRTC DataChannels for direct peer gameplay. The signaling server should know only what is needed to pair and connect peers.
- Be precise: WebRTC encrypts transport, but this does not by itself prove the person on the other end is who they claim to be. A hostile signaling service can affect peer identity unless identity is verified. Add peer fingerprints / a short authentication code or a stronger verified identity mechanism before making strong end-to-end claims.
- Keep the local companion local for the first MVP. If a hosted model is later used, make an explicit mode switch and disclose that the selected content goes to a model provider. Never imply both modes have the same privacy properties.
- Collect the minimum analytics possible. Never collect private answers just to personalize prompts.
- Use short TTLs for room metadata, protect report records, and define which staff roles can access them.

## 90-day build sequence

**Weeks 1–2:** run moderated tests with 10–20 pairs. Observe time to first prompt, confusing UI, skip comfort, and whether rating feels encouraging or judgmental.

**Weeks 3–4:** stabilize signaling and WebRTC reconnection; integrate TURN; add block/abuse queues; create accessibility checks and automated browser tests.

**Weeks 5–8:** run two measurable retention experiments; build curated prompt packs and prompt feedback; validate users return with the same partner.

**Weeks 9–12:** test pricing with a small paid pack, audit safety cases, measure organic invitation rate, then decide whether to invest in creator tools, group mode, or richer AI.

## The hard truth about “a trillion-dollar app”

A good interface does not create a trillion-dollar business by itself. A credible path starts with an intense niche, repeated mutual value, safe sharing, and a reason the product becomes part of a real-world ritual. The best next milestone is not a huge feature list: it is proving that two people choose to return for another session—and both feel good about it.


## UX scope reduction (October 2026)

The MVP surface is intentionally restricted to four actions: create/join a room, find a player, play the prompt, and chat/call during the session. Secondary social destinations, sound toggles, redundant onboarding cards, and profile-heavy navigation are hidden from the primary experience. The game screen prioritizes the current prompt and the active conversation.

Video calling reuses the live peer connection and requires explicit browser camera/microphone permission. The receiver must accept the call before the initiating device requests media. Calls should be tested on HTTPS with TURN configured before any public launch.
