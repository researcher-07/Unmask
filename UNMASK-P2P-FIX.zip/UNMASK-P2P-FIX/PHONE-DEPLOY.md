# UNMASK: fix the signaling-server error (phone-friendly checklist)

## Why it happens

The one-file Netlify demo is static HTML only. It cannot run the Node.js/WebSocket service that creates rooms, matches players, and exchanges the WebRTC connection setup. The result is a signaling-server error or fallback to Nova. This package includes both the website (`public/`) and the signaling service (`server.js`).

## Recommended: deploy the whole app as one service

1. Extract this ZIP on your phone. You should see `server.js`, `package.json`, `render.yaml`, and the `public` folder together.
2. Put these extracted files and folders in the **root** of a GitHub repository. Do not upload the ZIP as a single file; GitHub/Render must see `package.json` and `server.js` as files in the repository root. Keep `.env` files and any real credentials out of Git.
3. In Render, create a new **Blueprint** from that GitHub repository (or create a **Web Service** from it). The included `render.yaml` sets the build command to `npm install`, start command to `npm start`, health check to `/healthz`, and free beta plan.
4. Wait for the service to finish deploying. Open the generated `https://….onrender.com` URL. Use this Render URL for the app; no separate signaling URL is needed.
5. Test it from two different devices/browsers: on device A choose **Create a room** and share the code; on device B open the same Render URL and join the code. Then test chat and video call.

If creating a GitHub repo from a phone is awkward, the technical settings for Render are: **Web Service** (not Static Site), build `npm install`, start `npm start`, project/root directory containing `package.json`, `server.js`, `public/`, and `render.yaml`.

## If you want to keep the existing Netlify website

Deploy this package as a separate Render Web Service, then:

1. In Render → the service → Environment, set `ALLOWED_ORIGINS` to the exact Netlify origin, e.g. `https://YOUR-SITE.netlify.app` (no path and no trailing slash). If you use a custom domain, include that origin too, comma-separated.
2. Redeploy/restart the Render service after saving the environment variable.
3. Open the Netlify version of UNMASK → **Me** → **Advanced connection settings**. Enter the backend's `https://….onrender.com` URL and tap **Save and reconnect**.
4. Reopen UNMASK and test with a second device.

## What “peer-to-peer” means here

The signaling server is still required to introduce the two browsers and exchange WebRTC offer/answer/ICE setup messages. After setup, chat/game data and audio/video try to travel directly between the two browsers using WebRTC. On some networks, a TURN relay is necessary, so traffic is not guaranteed to be physically direct on every connection. The app currently includes a public STUN default, but reliable calls across restrictive mobile/Wi-Fi networks may need a TURN provider.

## Free-hosting note

Render's free web services can sleep after inactivity and take about a minute to wake; they may also restart. This is suitable for testing, not a promise of always-on service. See Render's current free-plan docs before relying on it for real users.
