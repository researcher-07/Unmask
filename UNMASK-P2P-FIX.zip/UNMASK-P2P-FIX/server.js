'use strict';

// UNMASK signaling service. Private gameplay/chat travels through the WebRTC
// DataChannel after the connection is established; this service only coordinates
// rooms, matchmaking, and WebRTC negotiation. Deploy behind HTTPS/WSS.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { WebSocketServer, WebSocket } = require('ws');

const PORT = Number(process.env.PORT || 4173);
const HOST = '0.0.0.0';
const ROOT = path.join(__dirname, 'public');
const ROOM_TTL_MS = 2 * 60 * 60 * 1000;
const MAX_CLIENTS = Number(process.env.MAX_CLIENTS || 1500);
const PUBLIC_FILES = new Set(['index.html', 'manifest.json', 'icon.svg', 'icon-192.png', 'icon-512.png', 'apple-touch-icon.png', 'service-worker.js']);
const VIBES = new Set(['Real', 'Playful', 'Deep', 'Dark', 'Chaos']);
const REPORTS = new Set(['Uncomfortable prompt', 'Harassment', 'Spam or misuse', 'Other concern']);
function configuredIceServers() {
  const fallback = [{ urls: 'stun:stun.l.google.com:19302' }];
  if (!process.env.ICE_SERVERS_JSON) return fallback;
  try {
    const parsed = JSON.parse(process.env.ICE_SERVERS_JSON);
    if (!Array.isArray(parsed) || parsed.length > 8) return fallback;
    const valid = parsed.filter(item => item && typeof item === 'object' && (typeof item.urls === 'string' || (Array.isArray(item.urls) && item.urls.every(x => typeof x === 'string'))) && (!item.username || typeof item.username === 'string') && (!item.credential || typeof item.credential === 'string')).map(item => ({ urls: item.urls, ...(item.username ? { username: item.username } : {}), ...(item.credential ? { credential: item.credential } : {}), ...(item.credentialType === 'password' ? { credentialType: 'password' } : {}) }));
    return valid.length ? valid : fallback;
  } catch { return fallback; }
}
const ICE_SERVERS = configuredIceServers();
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.svg': 'image/svg+xml; charset=utf-8',
  '.png': 'image/png'
};

function securityHeaders(res) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Permissions-Policy', 'camera=(self), microphone=(self), geolocation=(), payment=()');
  res.setHeader('Cross-Origin-Resource-Policy', 'same-origin');
  res.setHeader('X-DNS-Prefetch-Control', 'off');
  res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com data:; img-src 'self' data: blob:; media-src 'self' blob:; connect-src 'self' ws: wss:; object-src 'none'; base-uri 'self'; frame-ancestors 'none'; form-action 'self'");
}

const server = http.createServer((req, res) => {
  securityHeaders(res);
  if (!['GET', 'HEAD'].includes(req.method || '')) {
    res.writeHead(405, { Allow: 'GET, HEAD' });
    return res.end('Method not allowed');
  }
  let pathname;
  try { pathname = decodeURIComponent(new URL(req.url || '/', 'http://localhost').pathname); }
  catch { res.writeHead(400); return res.end('Bad request'); }
  // Lightweight health endpoint for deployment platforms. It returns no
  // application/session data and is checked before the static-file allow-list.
  if (pathname === '/healthz') {
    res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' });
    return res.end(req.method === 'HEAD' ? undefined : 'ok');
  }
  if (pathname === '/') pathname = '/index.html';
  if (pathname.includes('..') || pathname.includes('\\') || pathname.startsWith('/.')) {
    res.writeHead(404); return res.end('Not found');
  }
  const filename = path.basename(pathname);
  if (!PUBLIC_FILES.has(filename) || pathname !== `/${filename}`) {
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' });
    return res.end('Not found');
  }
  const full = path.join(ROOT, filename);
  fs.readFile(full, (err, data) => {
    if (err) { res.writeHead(404, { 'Cache-Control': 'no-store' }); return res.end('Not found'); }
    const headers = {
      'Content-Type': MIME[path.extname(filename)] || 'application/octet-stream',
      'Cache-Control': filename === 'index.html' ? 'no-cache' : 'public, max-age=300'
    };
    res.writeHead(200, headers);
    if (req.method === 'HEAD') return res.end();
    res.end(data);
  });
});

const wss = new WebSocketServer({ noServer: true, maxPayload: 64 * 1024, perMessageDeflate: false });
server.on('upgrade', (req, socket, head) => {
  let url;
  try { url = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`); }
  catch { socket.destroy(); return; }
  if (url.pathname !== '/ws') { socket.destroy(); return; }

  // Browsers always send Origin for WebSocket handshakes. Require same-host by
  // default, or an explicit allow-list for split frontend/server deployments.
  const origin = req.headers.origin;
  if (origin) {
    let allowed = false;
    try {
      const parsed = new URL(origin);
      const allowedOrigins = (process.env.ALLOWED_ORIGINS || '').split(',').map(x => x.trim()).filter(Boolean);
      allowed = allowedOrigins.map(x => x.toLowerCase()).includes(parsed.origin.toLowerCase()) || parsed.host.toLowerCase() === String(req.headers.host || '').toLowerCase();
    } catch { allowed = false; }
    if (!allowed) { socket.write('HTTP/1.1 403 Forbidden\r\nConnection: close\r\n\r\n'); socket.destroy(); return; }
  }
  wss.handleUpgrade(req, socket, head, ws => wss.emit('connection', ws, req));
});

const clients = new Map();
const clientBySocket = new WeakMap();
const rooms = new Map();
const queue = [];
const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
function send(ws, data) {
  if (ws && ws.readyState === WebSocket.OPEN) {
    try { ws.send(JSON.stringify(data)); } catch { /* peer may be closing */ }
  }
}
function sendError(client, code, message) { send(client.ws, { type: 'error', code, message }); }
function safeName(value) { return String(value || 'Player').replace(/[<>\u0000-\u001f\u007f]/g, '').trim().slice(0, 22) || 'Player'; }
function safeCode(value) { return String(value || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 5); }
function newCode() {
  let code;
  do { code = Array.from({ length: 5 }, () => alphabet[crypto.randomInt(alphabet.length)]).join(''); }
  while (rooms.has(code));
  return code;
}
function removeFromQueue(id) {
  let i;
  while ((i = queue.indexOf(id)) >= 0) queue.splice(i, 1);
}
function cleanQueue() {
  for (let i = queue.length - 1; i >= 0; i--) if (!clients.has(queue[i])) queue.splice(i, 1);
}
function detachPeer(client, tellPeer = true) {
  const peerId = client.peerId;
  if (!peerId) return;
  client.peerId = null;
  const peer = clients.get(peerId);
  if (peer && peer.peerId === client.id) {
    peer.peerId = null;
    if (tellPeer) send(peer.ws, { type: 'peer-left' });
  }
}
function leaveRoom(client) {
  if (!client.roomCode) return;
  const code = client.roomCode;
  const room = rooms.get(code);
  client.roomCode = null;
  if (!room) return;
  if (room.hostId === client.id) {
    if (room.guestId) {
      const guest = clients.get(room.guestId);
      if (guest) { guest.roomCode = null; send(guest.ws, { type: 'room-closed' }); }
    }
    rooms.delete(code);
  } else if (room.guestId === client.id) {
    room.guestId = null;
    const host = clients.get(room.hostId);
    if (host) send(host.ws, { type: 'room-guest-left' });
  }
}
function pair(a, b, source) {
  const ca = clients.get(a), cb = clients.get(b);
  if (!ca || !cb || ca === cb || ca.peerId || cb.peerId) return false;
  removeFromQueue(a); removeFromQueue(b);
  ca.peerId = b; cb.peerId = a;
  send(ca.ws, { type: 'peer-ready', peerId: cb.id, peerName: cb.name, initiator: true, source });
  send(cb.ws, { type: 'peer-ready', peerId: ca.id, peerName: ca.name, initiator: false, source });
  return true;
}
function pickMatch(client) {
  cleanQueue();
  const waiting = queue.filter(id => id !== client.id && clients.has(id) && !clients.get(id).peerId);
  let otherId = waiting.find(id => clients.get(id).vibe === client.vibe);
  if (!otherId) otherId = waiting[0];
  return otherId ? pair(client.id, otherId, 'random') : false;
}
function withinLimit(client, action, limit, windowMs) {
  const now = Date.now();
  const recent = (client.actionTimes.get(action) || []).filter(at => now - at < windowMs);
  if (recent.length >= limit) { client.actionTimes.set(action, recent); return false; }
  recent.push(now); client.actionTimes.set(action, recent); return true;
}
function hashPassphrase(password, salt) {
  return crypto.scryptSync(String(password).slice(0, 80), salt, 32, { N: 1 << 14, r: 8, p: 1, maxmem: 64 * 1024 * 1024 });
}
function validSignal(data) {
  if (!data || typeof data !== 'object' || Array.isArray(data)) return false;
  if (data.kind === 'offer' || data.kind === 'answer') {
    const d = data.description;
    return d && d.type === data.kind && typeof d.sdp === 'string' && d.sdp.length > 0 && d.sdp.length <= 50000;
  }
  if (data.kind === 'ice') {
    const c = data.candidate;
    if (c == null) return true;
    return typeof c === 'object' && typeof c.candidate === 'string' && c.candidate.length <= 4096;
  }
  return false;
}
function closeRoomIfExpired() {
  const now = Date.now();
  for (const [code, room] of rooms) {
    if (now - room.createdAt <= ROOM_TTL_MS) continue;
    for (const id of [room.hostId, room.guestId]) {
      const c = id ? clients.get(id) : null;
      if (c && c.roomCode === code) { c.roomCode = null; send(c.ws, { type: 'room-expired' }); }
    }
    rooms.delete(code);
  }
}

wss.on('connection', ws => {
  if (clients.size >= MAX_CLIENTS) { send(ws, { type: 'error', code: 'SERVER_FULL', message: 'UNMASK is busy right now. Please try again shortly.' }); ws.close(1013, 'Server busy'); return; }
  const id = crypto.randomUUID();
  const client = { id, ws, name: 'Player', vibe: 'Real', peerId: null, roomCode: null, alive: true, actionTimes: new Map() };
  clients.set(id, client);
  clientBySocket.set(ws, client);
  send(ws, { type: 'ready', clientId: id, iceServers: ICE_SERVERS });
  ws.on('pong', () => { client.alive = true; });

  ws.on('message', raw => {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { sendError(client, 'BAD_MESSAGE', 'That message was not valid JSON.'); return; }
    if (!msg || typeof msg.type !== 'string' || msg.type.length > 32) return;
    if (!withinLimit(client, 'all', 120, 10000)) { sendError(client, 'RATE_LIMITED', 'Too many messages. Pause for a moment and try again.'); return; }

    if (msg.type === 'profile') {
      if (!withinLimit(client, 'profile', 30, 60000)) return;
      client.name = safeName(msg.name);
      client.vibe = VIBES.has(msg.vibe) ? msg.vibe : 'Real';
      return;
    }

    if (msg.type === 'matchmake') {
      if (!withinLimit(client, 'matchmake', 8, 60000)) { sendError(client, 'RATE_LIMITED', 'Please wait before searching again.'); return; }
      removeFromQueue(client.id);
      if (client.peerId) detachPeer(client, true);
      leaveRoom(client);
      client.name = safeName(msg.name || client.name);
      client.vibe = VIBES.has(msg.vibe) ? msg.vibe : 'Real';
      if (!pickMatch(client)) { queue.push(client.id); send(ws, { type: 'searching', queued: true }); }
      return;
    }

    if (msg.type === 'cancel-match') {
      removeFromQueue(client.id);
      send(ws, { type: 'match-cancelled' });
      return;
    }

    if (msg.type === 'create-room') {
      if (!withinLimit(client, 'room', 8, 60000)) { sendError(client, 'RATE_LIMITED', 'Please wait before creating another room.'); return; }
      removeFromQueue(client.id);
      if (client.peerId) detachPeer(client, true);
      leaveRoom(client);
      const privacy = msg.privacy === 'password' ? 'password' : 'invite';
      const password = String(msg.password || '');
      if (privacy === 'password' && (password.length < 4 || password.length > 80)) { sendError(client, 'BAD_PASSWORD', 'Use a passphrase between 4 and 80 characters.'); return; }
      const code = newCode();
      const room = { code, hostId: client.id, guestId: null, vibe: VIBES.has(msg.vibe) ? msg.vibe : 'Real', privacy, createdAt: Date.now(), passwordSalt: null, passwordHash: null };
      if (privacy === 'password') {
        room.passwordSalt = crypto.randomBytes(16);
        room.passwordHash = hashPassphrase(password, room.passwordSalt);
      }
      rooms.set(code, room);
      client.roomCode = code; client.vibe = room.vibe; client.name = safeName(msg.name || client.name);
      send(ws, { type: 'room-created', code, vibe: room.vibe, privacy });
      return;
    }

    if (msg.type === 'join-room') {
      if (!withinLimit(client, 'join', 10, 60000)) { sendError(client, 'RATE_LIMITED', 'Too many room attempts. Wait a moment before trying again.'); return; }
      const code = safeCode(msg.code);
      const room = rooms.get(code);
      if (!room) { sendError(client, 'ROOM_NOT_FOUND', 'Room not found. Check the code and try again.'); return; }
      if (room.hostId === client.id) { sendError(client, 'SAME_PLAYER', 'Open the invite on another device to join your room.'); return; }
      if (room.guestId) { sendError(client, 'ROOM_FULL', 'That room already has two players.'); return; }
      if (room.privacy === 'password') {
        const supplied = String(msg.password || '');
        if (!supplied || supplied.length > 80) { sendError(client, 'BAD_PASSWORD', 'Enter the room passphrase.'); return; }
        const incoming = hashPassphrase(supplied, room.passwordSalt);
        if (!crypto.timingSafeEqual(incoming, room.passwordHash)) { sendError(client, 'BAD_PASSWORD', 'That passphrase did not match.'); return; }
      }
      removeFromQueue(client.id);
      if (client.peerId) detachPeer(client, true);
      leaveRoom(client);
      room.guestId = client.id; client.roomCode = code; client.vibe = room.vibe; client.name = safeName(msg.name || client.name);
      pair(room.hostId, client.id, 'room');
      return;
    }

    if (msg.type === 'signal') {
      if (!validSignal(msg.data)) { sendError(client, 'BAD_SIGNAL', 'Invalid WebRTC connection message.'); return; }
      const peer = client.peerId ? clients.get(client.peerId) : null;
      if (peer && peer.peerId === client.id) send(peer.ws, { type: 'signal', from: client.id, data: msg.data });
      return;
    }

    if (msg.type === 'report') {
      if (!withinLimit(client, 'report', 5, 60000)) { sendError(client, 'RATE_LIMITED', 'Please wait before submitting another report.'); return; }
      const category = REPORTS.has(msg.category) ? msg.category : 'Other concern';
      // MVP reports are console-only; never log private answers or message content.
      console.warn('[UNMASK REPORT]', JSON.stringify({ at: new Date().toISOString(), reporterId: client.id, reportedPeerId: client.peerId || null, roomCode: client.roomCode || null, category }));
      send(ws, { type: 'report-received' });
      return;
    }

    if (msg.type === 'leave') {
      removeFromQueue(client.id);
      if (client.peerId) detachPeer(client, true);
      leaveRoom(client);
      send(ws, { type: 'left' });
      return;
    }
  });

  ws.on('close', () => {
    removeFromQueue(client.id);
    if (client.peerId) detachPeer(client, true);
    leaveRoom(client);
    clients.delete(client.id);
  });
  ws.on('error', () => {});
});

const heartbeat = setInterval(() => {
  closeRoomIfExpired();
  for (const ws of wss.clients) {
    const c = clientBySocket.get(ws);
    if (!c) continue;
    if (!c.alive) { ws.terminate(); continue; }
    c.alive = false;
    try { ws.ping(); } catch { ws.terminate(); }
  }
}, 30000);
heartbeat.unref();
server.on('close', () => { clearInterval(heartbeat); });

server.listen(PORT, HOST, () => {
  console.log(`UNMASK is listening on ${PORT}`);
  console.log('Public static routes are allow-listed. Deploy behind HTTPS/WSS; configure TURN, persistence, and moderation before public launch.');
});
