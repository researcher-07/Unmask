# UNMASK — Truth or Dare

Mobile-first two-player game with rooms, random matchmaking, WebRTC data-channel chat/game messages, video-call controls, and a local rule-based companion named Nova.

## Quick deploy

See [PHONE-DEPLOY.md](PHONE-DEPLOY.md) for phone-friendly deployment instructions. The included `render.yaml` deploys the website and WebSocket signaling service together as a Render Web Service, avoiding cross-origin signaling settings.

## Run locally

Requires Node.js 20+.

```bash
npm install
npm start
```

Open `http://localhost:4173`. Run `npm test` for server protocol smoke tests and `npm run check` for syntax/client checks.

## Important architecture note

A browser-only static site cannot implement online rooms by itself. The Node.js signaling service is required to match players and exchange WebRTC connection setup messages. Normal game/chat data and audio/video then use WebRTC between browsers where network conditions permit; some connections need a TURN relay. Nova is local and rule-based, not a hosted generative AI.

## Before public launch

This remains an MVP scaffold and has not had a full cross-browser, load, privacy, abuse-moderation, or security audit. Add and test TURN service configuration, production moderation/report review, durable storage, and privacy/consent policies before inviting the public.
