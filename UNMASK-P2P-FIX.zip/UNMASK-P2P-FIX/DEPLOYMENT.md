# Deploy UNMASK (free beta)

These steps are for a small beta, not guaranteed always-on production hosting. Free plans can sleep, enforce quotas, and change their terms.

## Option A — easiest: one Node service

This is the recommended first deployment because the website and WebSocket signaling server share one HTTPS origin.

1. Create a GitHub repository and upload the files in this project. Keep `.env`, TURN credentials, and any real secrets out of Git.
2. Create a Node web service on a host that supports long-lived WebSockets.
3. Set the build/install command to `npm install` and the start command to `npm start`.
4. The server binds to `0.0.0.0` and uses the platform's `PORT` environment variable automatically.
5. Open the generated HTTPS URL on two different devices.
6. Test: create room → copy code → join from second device → exchange prompts and chat → accept a video call → mute/camera-off/hang up.

The same-origin WebSocket URL is picked automatically. No signaling URL configuration is needed.

## Option B — Cloudflare Pages frontend + Node signaling server

Choose this if you want a static host for the website and a separate Node host for WebSockets.

### Frontend

1. Connect the GitHub repo to Cloudflare Pages.
2. Set the build command to empty/no-build and the output directory to `public`.
3. Deploy. Only the `public/` folder is published; server source, tests, and project notes are outside it.

### Signaling service

1. Deploy the same GitHub repo as a Node web service; use `npm install` and `npm start`.
2. In the service's environment variables, set `ALLOWED_ORIGINS` to exact frontend origins, separated by commas. Example: `https://your-project.pages.dev,https://yourdomain.com`. Do not add paths or a trailing slash.
3. Wait for the backend's HTTPS URL, such as `https://your-unmask-server.example.com`.
4. Open the frontend, tap the small settings/gear icon, open **Advanced connection settings**, enter the backend's public HTTPS URL, and choose **Save and reconnect**.
5. Re-test the full two-device flow. If the origin is not allow-listed, the browser's WebSocket handshake is intentionally rejected.

## TURN for reliable calls

The default STUN server helps browsers discover direct paths but will not work on every network. Use a TURN provider for reliable calls, especially on mobile data and restrictive Wi-Fi. Add its server list to the Node service as `ICE_SERVERS_JSON`, formatted as JSON. The server sends configured ICE server entries to connected browsers when signaling starts.

Use expiring/temporary TURN credentials where possible. Do not store provider master credentials in a public repo or frontend. TURN relay usage can incur costs even if all app hosting is free.

## Verify after deployment

From the project directory run:

```bash
npm install
npm run check
npm test
```

`npm test` checks static route exposure/security headers, private room pairing, message validation/forwarding, and passphrase behavior. The local checks do not validate camera permissions or actual multi-network video quality; do that manually on separate devices.

## Expected free-tier tradeoffs

- Node services may sleep and take time to wake, which hurts matchmaking and incoming calls.
- Room state and matchmaking are in memory: a server restart clears them and multiple service instances will not share them.
- TURN relays may cost money based on bandwidth.
- Current reports are written to server logs only; a public launch needs a durable moderation queue and operations process.
